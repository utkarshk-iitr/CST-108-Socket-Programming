#!/bin/bash

openssl rand -hex 16 > aes_key
openssl enc -aes-128-ecb -e -in Sample.bmp -out Sample_ecb.enc -K $(cat aes_key)
openssl enc -aes-128-cbc -e -in Sample.bmp -out Sample_cbc.enc -K $(cat aes_key) -iv 00112233445566778889aabbccddeeff

head -c 54 Sample.bmp > header
tail -c +55 Sample_ecb.enc > body
cat header body > new_ecb.bmp

tail -c +55 Sample_cbc.enc > body
cat header body > new_cbc.bmp

# Observations -

# ECB Mode: We can see patterns and outlines from the original image 
#           because identical plaintext blocks produce identical ciphertext blocks.
# CBC Mode: The encrypted image appears is a complete noise and no patterns is seen 
#           because each block's encryption depends on the previous block by use of IV